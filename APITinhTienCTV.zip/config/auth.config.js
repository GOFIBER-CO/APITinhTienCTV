module.exports = {
    secret : "CMSAPINEWS",
    jwtExpiration : 50000,
    jwtRefreshExpiration : 600000
}