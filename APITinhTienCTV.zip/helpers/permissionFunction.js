const permissionFunction = {
  USER: "user",
};

module.exports = permissionFunction;
