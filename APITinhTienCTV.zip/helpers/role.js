module.exports = {
  Admin: "Admin",
  Leader: "Leader",
  Member: "Member",
};
