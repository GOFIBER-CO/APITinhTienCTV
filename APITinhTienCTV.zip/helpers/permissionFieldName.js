const permissionFieldName = {
    ADD: 'add',
    DELETE: 'delete',
    EDIT: 'edit',
}

module.exports = permissionFieldName